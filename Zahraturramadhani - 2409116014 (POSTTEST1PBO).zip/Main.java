// Post Test 1 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest1pbo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    static class Transaksi {

        int id;
        String tanggal;           
        String keterangan;
        String jenis;             
        String kategori;          
        String metodePembayaran;  
        double jumlah;

        Transaksi(int id, String tanggal, String keterangan, String jenis,
                String kategori, String metodePembayaran, double jumlah) {
            this.id = id;
            this.tanggal = tanggal;
            this.keterangan = keterangan;
            this.jenis = jenis;
            this.kategori = kategori;
            this.metodePembayaran = metodePembayaran;
            this.jumlah = jumlah;
        }
    }

    static ArrayList<Transaksi> daftar = new ArrayList<>();
    static Scanner input = new Scanner(System.in);
    static int autoId = 1;
    static double batasPengeluaranBulanan = 0; // 0 = kalau masih 0 belum diset batasnya

    public static void main(String[] args) {
        int pilih;

        // Data Awal
        daftar.add(new Transaksi(autoId++, "2025-09-01", "Gaji Bulanan",
                "Pemasukan", "Gaji", "Transfer", 5_000_000));
        daftar.add(new Transaksi(autoId++, "2025-09-02", "Beli Makan Siang",
                "Pengeluaran", "Makan", "Cash", 25_000));
        daftar.add(new Transaksi(autoId++, "2025-09-03", "Ongkos Transportasi",
                "Pengeluaran", "Transportasi", "Cash", 10_000));
        daftar.add(new Transaksi(autoId++, "2025-09-04", "Nonton Bioskop",
                "Pengeluaran", "Hiburan", "E-Wallet", 50_000));
        daftar.add(new Transaksi(autoId++, "2025-09-05", "Beli Pakaian",
                "Pengeluaran", "Belanja", "Transfer", 200_000));
        daftar.add(new Transaksi(autoId++, "2025-09-06", "Menabung Rutin",
                "Pemasukan", "Tabungan", "Transfer", 500_000));
        daftar.add(new Transaksi(autoId++, "2025-09-07", "Bayar Listrik",
                "Pengeluaran", "Tagihan", "E-Wallet", 150_000));
        daftar.add(new Transaksi(autoId++, "2025-09-08", "Bayar Air",
                "Pengeluaran", "Tagihan", "Transfer", 100_000));
        daftar.add(new Transaksi(autoId++, "2025-09-09", "Isi Saldo Tabungan",
                "Pemasukan", "Tabungan", "Transfer", 300_000));
        daftar.add(new Transaksi(autoId++, "2025-09-10", "Makan Malam di Restoran",
                "Pengeluaran", "Makan", "Cash", 75_000));
        daftar.add(new Transaksi(autoId++, "2025-09-10", "Bonus Proyek Mega",
                "Pemasukan", "Gaji", "Transfer", 500_000));

        daftar.add(new Transaksi(autoId++, "2025-09-11", "Beli Bensin 1 Liter",
                "Pengeluaran", "Transportasi", "Cash", 50_000));
        
        do {
            System.out.println("+=======================================+");
            System.out.println("|     SELAMAT DATANG DI POCKET GUARD    |");
            System.out.println("| Aplikasi Catatan Keuangan Harian Anda |");
            System.out.println("+=======================================+");
            System.out.println("|              MENU UTAMA               |");
            System.out.println("+=======================================+");
            System.out.println("| 1. Tambah Catatan Keuangan            |");
            System.out.println("| 2. Lihat Semua Catatan Keuangan       |");
            System.out.println("| 3. Ubah Catatan Keuangan              |");
            System.out.println("| 4. Hapus Catatan Keuangan             |");
            System.out.println("| 5. Ringkasan Saldo                    |");
            System.out.println("| 6. Filter Catatan                     |");
            System.out.println("| 7. Set Batas Pengeluaran              |");
            System.out.println("| 8. Keluar                             |");
            System.out.println("+=======================================+");
            System.out.print("-> Silakan Pilih Menu Yang Diinginkan [1-8]: ");
            pilih = safeNextInt();

            switch (pilih) {
                case 1 -> tambahCatatan();
                case 2 -> lihatSemuaCatatan();
                case 3 -> ubahCatatan();
                case 4 -> hapusCatatan();
                case 5 -> ringkasanSaldo();
                case 6 -> menuFilter();
                case 7 -> setBatasPengeluaran();
                case 8 -> {
                    System.out.println("\n+=================================================+");
                    System.out.println("|   Terima kasih telah menggunakan POCKET GUARD   |");
                    System.out.println("|  Semoga keuangan Anda selalu aman & terjaga !!  |");
                    System.out.println("+=================================================+");
                }
                default -> {
                    System.out.println("\n+=================================================+");
                    System.out.println("|    Pilihan tidak valid. Silakan coba lagi!!!    |");
                    System.out.println("+=================================================+\n");
                }
            }
        } while (pilih != 8);
    }

    // CRUD 
    // Tambah Catatan
    static void tambahCatatan() {
        String ulang;
        do {
            System.out.println("\n=================================================================================");
            System.out.println("                              TAMBAH CATATAN KEUANGAN                            ");
            System.out.println("=================================================================================");

            System.out.print("-> Silakan Input Tanggal (Format yyyy-mm-dd): ");
            String tanggal = input.nextLine();
            System.out.print("-> Silakan Input Keterangannya : ");
            String keterangan = input.nextLine();
            System.out.print("-> Silakan Input Jenis Transaksinya (Pemasukan/Pengeluaran): ");
            String jenis = input.nextLine();
            System.out.print("-> Silakan Input Kategori Transaksinya (gaji, makan, transportasi, hiburan, belanja, tabungan,tagihan): ");
            String kategori = input.nextLine();
            System.out.print("-> Silakan Input Metode Pembayaran (Cash/E-Wallet/Transfer): ");
            String metode = input.nextLine();
            System.out.print("-> Silakan Input Nominal Transaksinya : ");
            double jumlah = safeNextDouble();

            daftar.add(new Transaksi(autoId++, tanggal, keterangan, jenis, kategori, metode, jumlah));
            System.out.println("\n Data Berhasil Ditambahkan");

            // Peringatan batas bulanan
            if (batasPengeluaranBulanan > 0) {
                double totalKeluar = hitungTotalJenis("Pengeluaran");
                if (totalKeluar > batasPengeluaranBulanan) {
                    System.out.println("\n Peringatan: Pengeluaran melebihi batas bulanan (" +
                            formatRupiah(batasPengeluaranBulanan) + "). Total saat ini: " + formatRupiah(totalKeluar));
                }
            }

            lihatSemuaCatatan();

            System.out.print("\n Apakah Ingin Menambah Catatan Lagi? (Y/T): ");
            ulang = input.nextLine();
            System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }
    
    // Lihat Catatan
    static void lihatSemuaCatatan() {
        tampilkanTabel(daftar);
    }

    // Ubah Catatan
    static void ubahCatatan() {
        String ulang;
        do {
            System.out.println("\n=================================================================================");
            System.out.println("                               UBAH CATATAN KEUANGAN                             ");
            System.out.println("=================================================================================");
            lihatSemuaCatatan();
            System.out.print("-> Masukkan ID Yang Ingin Diubah: ");
            int id = safeNextInt();

            boolean ketemu = false;
            for (Transaksi t : daftar) {
                if (t.id == id) {
                    t.tanggal = inputStringOpsional("-> Input Tanggal baru: ", t.tanggal);
                    t.keterangan = inputStringOpsional("-> Input Keterangan baru: ", t.keterangan);
                    t.jenis = inputStringOpsional("-> Input Jenis baru (Pemasukan/Pengeluaran): ", t.jenis);
                    t.kategori = inputStringOpsional("-> Input Kategori baru: ", t.kategori);
                    t.metodePembayaran = inputStringOpsional("-> Input Metode Pembayaran baru: ", t.metodePembayaran);
                    t.jumlah = inputDoubleOpsional("-> Input Nominal Transaksi baru: ", t.jumlah);

                    System.out.println("\n Data berhasil diubah");
                    ketemu = true;
                    break;
                }
            }
            if (!ketemu) {
                System.out.println("\n ID tidak ditemukan");
            }

            lihatSemuaCatatan();

            System.out.print("\n Apakah Ingin Mengubah Catatan Lagi? (Y/T): ");
            ulang = input.nextLine();
            System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }
    
    // Hapus Catatn
    static void hapusCatatan() {
        String ulang;
        do {
            System.out.println("\n=================================================================================");
            System.out.println("                               HAPUS CATATAN KEUANGAN                            ");
            System.out.println("=================================================================================");

            lihatSemuaCatatan();

            System.out.print("-> Masukkan ID Yang Ingin Dihapus: ");
            int id = safeNextInt();

            int idx = -1;
            for (int i = 0; i < daftar.size(); i++) {
                if (daftar.get(i).id == id) {
                    idx = i;
                    break;
                }
            }

            if (idx == -1) {
                System.out.println("\n ID tidak ditemukan");
            } else {
                // konfirmasi dulu sebelum hapus
                System.out.print("Apakah Anda Yakin Ingin Menghapus Data Dengan ID " + id + " ? (Y/T): ");
                String ya = input.nextLine().trim().toLowerCase();
                if (ya.equals("y")) {
                    daftar.remove(idx);
                    System.out.println("\n Data berhasil dihapus");
                } else {
                    System.out.println("\n Penghapusan dibatalkan");
                }
            }

            System.out.print("\n Apakah Ingin Menghapus Catatan Lagi? (Y/T): ");
            ulang = input.nextLine();
            System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }

    // Ringkasan Saldo
    static void ringkasanSaldo() {
        double totalMasuk = hitungTotalJenis("Pemasukan");
        double totalKeluar = hitungTotalJenis("Pengeluaran");
        System.out.println("\n=================================================================================");
        System.out.println("                                    Ringkasan Saldo                              ");
        System.out.println("=================================================================================");

        System.out.println("Total Pemasukan   : " + formatRupiah(totalMasuk));
        System.out.println("Total Pengeluaran : " + formatRupiah(totalKeluar));
        System.out.println("Saldo             : " + formatRupiah(totalMasuk - totalKeluar));
        System.out.println("================================================================================");

        if (totalKeluar > totalMasuk) {
            System.out.println("\n Catatan: Pengeluaran lebih besar dari pemasukan. Harap bijak mengatur keuangan\n");
        }

        int kembali;
        do {
            System.out.print("-> Ketik 0 untuk kembali ke menu: ");
            kembali = safeNextInt();
        } while (kembali != 0);
        System.out.println();
    }

    // Set Batas Pengeluaran
    static void setBatasPengeluaran() {
        System.out.println("\n=================================================================================");
        System.out.println("                           Set Batas Pengeluaran Bulanan                         ");
        System.out.println("=================================================================================");
        System.out.println("Batas saat ini : " + (batasPengeluaranBulanan <= 0
                ? "— (tidak diaktifkan)"
                : formatRupiah(batasPengeluaranBulanan)));
        System.out.print("-> Masukkan batas baru (ketik 0 untuk menonaktifkan): ");

        batasPengeluaranBulanan = safeNextDouble();

        if (batasPengeluaranBulanan <= 0) {
            batasPengeluaranBulanan = 0;
            System.out.println("\nBatas pengeluaran bulanan dinonaktifkan");
        } else {
            System.out.println("\nBatas disetel: " + formatRupiah(batasPengeluaranBulanan));
            double totalKeluar = hitungTotalJenis("Pengeluaran");
            double sisa = batasPengeluaranBulanan - totalKeluar;

            System.out.println("Total pengeluaran saat ini: " + formatRupiah(totalKeluar));
            System.out.println("Sisa ruang anggaran       : " + formatRupiah(sisa));

            if (sisa < 0) {
                System.out.println("Peringatan: Pengeluaran sudah melebihi batas !!!");
            }
        }

        int kembali;
        do {
            System.out.print("-> Ketik 0 untuk kembali ke menu: ");
            kembali = safeNextInt();
        } while (kembali != 0);
        System.out.println();
    }

    // Filter Kategori
    static void menuFilter() {
        int pilih;
        do {
            System.out.println("\n===========================================================================");
            System.out.println("|                             MENU FILTER CATATAN                         |");
            System.out.println("===========================================================================");
            System.out.println("| 1. Filter per Jenis (Pemasukan/Pengeluaran)                             |");
            System.out.println("| 2. Filter per Kategori                                                  |");
            System.out.println("| 3. Filter per Metode Pembayaran                                         |");
            System.out.println("| 4. Kembali                                                              |");
            System.out.println("=========================================================================== ");
            System.out.print("Pilih [1-4]: ");
            pilih = safeNextInt();

            switch (pilih) {
                case 1 -> filterByJenis();
                case 2 -> filterByKategori();
                case 3 -> filterByMetode();
                case 4 -> System.out.println();
                default -> System.out.println("Pilihan tidak valid\n");
            }
        } while (pilih != 4);
    }
    
    // Filter Jenis
    static void filterByJenis() {
        System.out.println("\n=================================================================================");
        System.out.println("|                            Filter berdasarkan Jenis                           |");
        System.out.println("=================================================================================");
        System.out.print("-> Masukkan Jenis Transaksi (Pemasukan/Pengeluaran): ");
        String j = input.nextLine();

        ArrayList<Transaksi> hasil = new ArrayList<>();
        for (Transaksi t : daftar) {
            if (t.jenis.equalsIgnoreCase(j)) hasil.add(t);
        }
        if (hasil.isEmpty()) {
            System.out.println("\nTidak ada data dengan jenis tersebut");
        } else {
            tampilkanTabel(hasil); 
        }
    }

    // FiLter Kategori
    static void filterByKategori() {
        System.out.println("\n=================================================================================");
        System.out.println("|                           Filter berdasarkan Kategori                         |");
        System.out.println("=================================================================================");
        System.out.print("-> Masukkan Kategori (gaji, makan, transportasi, hiburan, belanja, tabungan,tagihan): ");
        String k = input.nextLine();

        ArrayList<Transaksi> hasil = new ArrayList<>();
        for (Transaksi t : daftar) {
            if (t.kategori.equalsIgnoreCase(k)) hasil.add(t);
        }
        if (hasil.isEmpty()) {
            System.out.println("\nTidak ada data dengan kategori tersebut");
        } else {
            tampilkanTabel(hasil); 
        }
    }

    // Filter Metode Pembayaran
    static void filterByMetode() {
        System.out.println("\n=================================================================================");
        System.out.println("|                       Filter berdasarkan Metode Pembayaran                    |");
        System.out.println("=================================================================================");
        System.out.print("-> Masukkan Metode (Cash/E-Wallet/Transfer): ");
        String m = input.nextLine();

        ArrayList<Transaksi> hasil = new ArrayList<>();
        for (Transaksi t : daftar) {
            if (t.metodePembayaran.equalsIgnoreCase(m)) hasil.add(t);
        }
        if (hasil.isEmpty()) {
            System.out.println("\nTidak ada data dengan metode tersebut");
        } else {
            tampilkanTabel(hasil); 
        }
    }

    // UTIL TABEL & PERHITUNGAN 
    static void tampilkanTabel(List<Transaksi> data) {
        // Lebar untuk kolom: ID, Tanggal, Jenis, Kategori, Metode, Jumlah, Keterangan
        int[] w = {4, 12, 12, 15, 12, 15, 30};

        System.out.println();
        System.out.println(garis(w));
        System.out.printf("| %-" + w[0] + "s | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                "ID", "Tanggal", "Jenis", "Kategori", "Metode", "Jumlah", "Keterangan");
        System.out.println(garis(w));

        if (data.isEmpty()) {
            System.out.printf("| %-" + (w[0] + w[1] + w[2] + w[3] + w[4] + w[5] + w[6] + 18) + "s |\n",
                    "Belum ada data transaksi");
        } else {
            for (Transaksi t : data) {
                String jumlahStr = formatRupiah(t.jumlah);
                String ket = t.keterangan.length() > w[6] ? t.keterangan.substring(0, w[6] - 3) + "..." : t.keterangan;

                System.out.printf("| %-" + w[0] + "d | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                        t.id, t.tanggal, t.jenis, t.kategori, t.metodePembayaran, jumlahStr, ket);
            }
        }
        System.out.println(garis(w));

        int kembali;
        do {
            System.out.print("-> Ketik 0 untuk kembali: ");
            kembali = safeNextInt();
        } while (kembali != 0);
        System.out.println();
    }

    static String garis(int[] widths) {
        StringBuilder sb = new StringBuilder();
        sb.append('+');
        for (int w : widths) {
            for (int i = 0; i < w + 2; i++) sb.append('-'); 
            sb.append('+');
        }
        return sb.toString();
    }

    static double hitungTotalJenis(String jenis) {
        double total = 0;
        for (Transaksi t : daftar) {
            if (t.jenis.equalsIgnoreCase(jenis)) total += t.jumlah;
        }
        return total;
    }

    static String formatRupiah(double nilai) {
        String s = String.format("%,.0f", nilai).replace(',', '.'); // Format penulisan nominal transaksi 1000000 -> 1.000.000
        return "Rp " + s;
    }
    
    // Helper input opsional
    static String inputStringOpsional(String prompt, String nilaiLama) {
        System.out.print(prompt);
        String v = input.nextLine();
        return v.isEmpty() ? nilaiLama : v;
    }

    static double inputDoubleOpsional(String prompt, double nilaiLama) {
        System.out.print(prompt);
        while (true) {
            String v = input.nextLine().trim();
            if (v.isEmpty()) {
                return nilaiLama;            // Enter = pakai nilai lama
            }
            try {
                return Double.parseDouble(v);
            } catch (NumberFormatException e) {
                System.out.print("Harus angka! Silakan input ulang: ");
            }
        }
    }

    // INPUT SAFE 
    static int safeNextInt() {
        while (true) {
            try {
                return Integer.parseInt(input.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Harus angka! Silakan input ulang: ");
            }
        }
    }

    static double safeNextDouble() {
        while (true) {
            try {
                return Double.parseDouble(input.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Harus angka! Silakan input ulang: ");
            }
        }
    }
}

